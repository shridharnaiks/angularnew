export class User{
constructor(
public Username ='',
public password ='',
public email ='',
public state?:string,
public zip?:string)
{}


}
    
