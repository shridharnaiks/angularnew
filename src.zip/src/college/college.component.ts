import { Component } from '@angular/core';

@Component({
    selector:'college-root',
    templateUrl:'./college.component.html',
   styleUrls:['./college.component.css']
   //template:'<h1>shri</h1>'
})
export class collegeComponent {
            movieName:string='shri';
            imageWidth:number=900;
            imageHeight:number=300;      
            //imageWidt:number=100;
           // imageHeigh:number=400;    
           // imageWid:number=100;
           // imageHeig:number=40;        
}