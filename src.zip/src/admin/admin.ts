export interface Icollege{
    cId:number;
    collegeName:string;
     cutOff:number; 
     place:string;
      zip:number;

}