import { Component } from '@angular/core';

@Component({
    selector:'sts-root',
    templateUrl:'./sts.component.html',
   styleUrls:['./sts.component.css']
   //template:'<h1>shri</h1>'
})
export class stsComponent {
               
            //imageWidt:number=100;
           // imageHeigh:number=400;    
           // imageWid:number=100;
           // imageHeig:number=40;        
}